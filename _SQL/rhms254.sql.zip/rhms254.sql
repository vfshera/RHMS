-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2020 at 10:33 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rhms254`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_access` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`id`, `project_id`, `type`, `user_id`, `user_access`, `created_at`, `updated_at`) VALUES
(1, '4', 'ENGINEER', '2', '1', '2020-11-17 21:20:55', NULL),
(2, '4', 'CONTRACTOR', '3', '2', '2020-08-02 21:21:02', NULL),
(3, '1', 'CONTRACTOR', '7', '2', '2020-11-05 09:06:48', '2020-11-05 09:06:48');

-- --------------------------------------------------------

--
-- Table structure for table `complains`
--

CREATE TABLE `complains` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `caption` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `read` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `complains`
--

INSERT INTO `complains` (`id`, `caption`, `location`, `image`, `read`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Nimekasirikaaaaa', 'Kenya', '1604384750_COMP_poster mascan.jpg', '0', '4', '2020-11-03 03:25:50', '2020-11-03 03:25:50');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `phone`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Franklin Shera', 'fshera96@gmail.com', '0700080373', 's sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', '2020-11-08 07:28:53', '2020-11-08 07:28:53'),
(2, 'Emid', 'fberu@mail.com', '1234567890', 'Heyyyyy', '2020-11-08 17:52:10', '2020-11-08 17:52:10');

-- --------------------------------------------------------

--
-- Table structure for table `contractors`
--

CREATE TABLE `contractors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cv` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qualification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contractors`
--

INSERT INTO `contractors` (`id`, `cv`, `qualification`, `user_id`, `location`, `created_at`, `updated_at`) VALUES
(1, '', '', '3', 'Mombasa', NULL, NULL),
(2, '1604577082_CONT_CV_WallX_168982_720x1280.jpeg', '1604577082_CONT_QUAL_35430978-face-baby-girl-newborn-baby-boy-cute-face-smile-stylized-vector-illustration-is-useful-for-signs-poi.jpg', '7', 'Lamu County', '2020-11-05 07:35:21', '2020-11-05 08:51:22');

-- --------------------------------------------------------

--
-- Table structure for table `engineers`
--

CREATE TABLE `engineers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cv` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qualification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `engineers`
--

INSERT INTO `engineers` (`id`, `cv`, `qualification`, `user_id`, `location`, `created_at`, `updated_at`) VALUES
(1, '1604679938_ENG_CV_VIDONYI  F  SHERA CV UPDATED.pdf', '1604679938_ENG_QUAL_NEW ID SHERA FRANKLIN 2020.pdf', '2', 'gg', NULL, '2020-11-06 13:25:38'),
(2, NULL, NULL, '6', NULL, '2020-11-05 07:31:04', '2020-11-05 07:31:04');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_10_31_205443_create_projects_table', 1),
(5, '2020_10_31_211113_create_contractors_table', 1),
(6, '2020_10_31_211217_create_engineers_table', 1),
(8, '2020_10_31_213432_create_applications_table', 1),
(9, '2020_11_03_054806_create_complains_table', 2),
(10, '2020_11_04_213009_create_showcases_table', 3),
(11, '2020_10_31_213104_create_ratings_table', 4),
(12, '2020_11_08_095952_create_contacts_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engineer_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contractor_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `starting_date` date NOT NULL,
  `project_span` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_finished` date DEFAULT NULL,
  `progress` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `image`, `title`, `engineer_id`, `contractor_id`, `starting_date`, `project_span`, `location`, `date_finished`, `progress`, `created_at`, `updated_at`) VALUES
(1, 'const.jpg', 'SIKOMANI', NULL, '7', '2020-03-15', '24 months', 'Lamu County', NULL, '0', '2020-10-31 19:04:36', '2020-11-08 08:20:40'),
(2, 'construction.jpg', 'NCHIRU', NULL, NULL, '2020-11-03', '7 months', 'Meru County', NULL, '0', '2020-10-31 19:04:36', '2020-10-31 19:04:36'),
(4, '1604247430_PROJ_WEMBE.png', 'SCHOOL ROAD', '2', '3', '2021-01-30', '21 MONTHS', 'MOMBASA', '2022-04-08', '1', '2020-11-01 13:17:10', '2020-11-02 22:53:43');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `project_id`, `rating`, `user_id`, `created_at`, `updated_at`) VALUES
(1, '4', '4.3', 8, '2020-11-05 22:32:57', '2020-11-05 22:32:57'),
(2, '4', '3.9', 4, '2020-11-05 22:34:13', '2020-11-05 22:34:13');

-- --------------------------------------------------------

--
-- Table structure for table `showcases`
--

CREATE TABLE `showcases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `before_img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `after_img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `caption` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access` int(11) NOT NULL,
  `status` int(21) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `image`, `name`, `email`, `email_verified_at`, `password`, `access`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, '1604664454_PROFILE_FB_IMG_1592376098368.jpg', 'Admin', 'admin@rhms.go.ke', NULL, '$2y$10$ta1T.O6LKZe0jW6hPhhNE.lNmEmON3ArhLKOb9k5tCdRHWsp1aFU2', 0, 1, NULL, '2020-10-31 19:04:35', '2020-11-06 09:07:35'),
(2, '1604437591_PROJ_gregooo.png', 'Anthony Greg', 'anto@engineers.org', NULL, '$2y$10$bJy2gb20BUGX.NsMY.2iZuay8WFJXK4QeckWc.eEAdvas3ZKkL.9.', 1, 1, 'veLR4lJbh0Kv6AqYZrsY4ukV01EyOjXoeLoYtDvC040TaG9fxjmNIM1GFCyK', '2020-10-31 19:04:35', '2020-11-03 18:06:31'),
(3, '1604437550_PROJ_SMOOOTHLINE.png', 'Jerry Fundi', 'jerryfundi@contractors.org', NULL, '$2y$10$xWu9I2nTQnyobnbTzdENVuDJYuSLTzoaovQM2s/aZpAFYPZztcb3y', 2, 1, 'gOdPKoUYfLWMPdKQKHlAMjHWss8vozTUJyajE4sh3JoP2cRwE1V6RFAF6xrB', '2020-10-31 19:04:35', '2020-11-03 18:05:51'),
(4, '1604664553_PROFILE_early.jpg', 'Joshua Ngulo', 'joshu254@citizen.co.ke', NULL, '$2y$10$31yO7YBLnEXkvfXBhyjrduWfAZNz.qBWvVb4dL3L6CA2LevpJgHNy', 3, 1, 'ppzZFPkf8VDz0UOELmG6zNwr1HWgVVU9plvAteLMVulZbA3gZZ8gE34GqGB5', '2020-10-31 19:04:36', '2020-11-06 09:09:13'),
(6, '1604572264_PROFILE_35430978-face-baby-girl-newborn-baby-boy-cute-face-smile-stylized-vector-illustration-is-useful-for-signs-poi.jpg', 'Avoze', 'mubeibe@avoze.com', NULL, '$2y$10$UtsLIjZHcO2MPS7pPEytUunDByhLX2.j2sTJXPQvELoUiOd.jwQqa', 1, 0, NULL, '2020-11-05 07:31:04', '2020-11-06 13:21:44'),
(7, '1604572521_PROFILE_SHERA SHOOT.png', 'Shera', 'shera@mail.com', NULL, '$2y$10$qsy57GcGMo1/yaw5t4FN/ejjkDapyzA2W.DexVfbH/ijjAPWnsq9.', 2, 1, NULL, '2020-11-05 07:35:21', '2020-11-08 08:21:32'),
(8, '1604624496_PROFILE_iconfinder_FL_Studio_99688.png', 'Fruit Finder', 'finder@citizen.co.ke', NULL, '$2y$10$ChCLll8Wcp11lZCpNHcet.dSNp6ZG8dYKagMBRI.aQHKQs2DXwSRS', 3, 1, NULL, '2020-11-05 22:01:39', '2020-11-05 22:01:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complains`
--
ALTER TABLE `complains`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contractors`
--
ALTER TABLE `contractors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `engineers`
--
ALTER TABLE `engineers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `showcases`
--
ALTER TABLE `showcases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `complains`
--
ALTER TABLE `complains`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contractors`
--
ALTER TABLE `contractors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `engineers`
--
ALTER TABLE `engineers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `showcases`
--
ALTER TABLE `showcases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
